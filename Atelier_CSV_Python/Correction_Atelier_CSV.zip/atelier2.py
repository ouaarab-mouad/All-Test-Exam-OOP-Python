import csv

def read_from_exam_results(csvfile = "exam_results.csv"):
    items = []
    with open(csvfile) as exam_results:
        reader = csv.DictReader(exam_results)
        for item in reader:
            items.append(item)
        return items


def prepar_rapport(exam_name = "Maths"):
    rapport = {"exam name": exam_name}
    items = read_from_exam_results()
    candidates = []
    grades = []
    scores = []
    for item in items:
        if item["Exam Name"] == exam_name:
            grades.append(item["Grade"])
            candidates.append(item["Candidate ID"])
            scores.append(item["Score"])
    nbr_candidates = len(set(candidates))
    nbr_passed = len(list(filter(lambda x: x == "Pass", grades)))
    nbr_failed = len(list(filter(lambda x: x == "Fail", grades)))
    best_score = max(scores)
    worst_score = min(scores)
    items = [("NumberOfCandidates", nbr_candidates), ("NumberOfPassedExams", nbr_passed), ("NumberOfFailedExams", nbr_failed), ("BestScore",best_score), ("WorstScore",worst_score)]
    for key,value in items:
        rapport[key]=value
    return rapport

def write_rapport_to_csv():
    with open("rapport.csv","w") as rapport:
        filednames = prepar_rapport().keys()
        writer = csv.DictWriter(rapport,filednames)
        writer.writeheader()
        exams = ["Maths","Physics","Biology"]
        for exam in exams:
            exam_rapport = prepar_rapport(exam)
            writer.writerow(exam_rapport)



write_rapport_to_csv()

