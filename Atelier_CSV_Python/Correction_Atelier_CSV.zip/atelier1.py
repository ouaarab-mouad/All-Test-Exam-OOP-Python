import csv

class PhoneContact:
    def __init__(self,Name,Phone):
        self.name = Name
        self.phone = Phone

    def __str__(self):
        return f"{self.name} -> {self.phone}"

class Phone:
    def __init__(self,csvfile = "contacts.csv"):
        self.contacts = self.load_contacts_from_csv(csvfile)

    def load_contacts_from_csv(self,csvfile):
        contacts = []
        with open(csvfile) as csv_contacts:
            filednames = ["Name","Phone"]
            reader = csv.DictReader(csv_contacts,fieldnames=filednames)
            for contact in reader:
                contacts.append(PhoneContact(**contact))
        return contacts[1:]

    def search_contact(self,word):
        result = []
        for contact in self.contacts:
            if word in contact.name or word in contact.phone:
                result.append(contact)
        return result

myPhone = Phone()
for contact in myPhone.contacts:
   print(contact)

print("Search for contacts with h in name:")
for contact in myPhone.search_contact("h"):
    print(contact)


