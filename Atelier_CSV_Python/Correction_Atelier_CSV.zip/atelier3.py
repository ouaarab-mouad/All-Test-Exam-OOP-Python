import csv
import json

def csv_reader(csv_file = "ma.csv"):
    villes = []
    with open(csv_file,"rt",encoding="utf-8") as ma:
        reader = csv.DictReader(ma)
        for ville in reader:
            villes.append(Ville(ville["city"],ville["region"],int(ville["population"]),\
                            True if ville["capital"]=="admin" else False))
    return villes

class Ville:
    def __init__(self,city_name,city_region,city_population,isAdmin):
        self.city_name = city_name
        self.city_region = city_region
        self.city_population = city_population
        self.isAdmin = isAdmin

class Region:
    def __init__(self,region_name):
        self.region_name = region_name
        self.capital = self.add_capital()
        self.region_population = self.add_population()
        self.villes = self.add_ville_names()

    def add_ville(self):
        villes_region = []
        for ville in csv_reader():
            if ville.city_region == self.region_name:
                villes_region.append(ville)
        return villes_region

    def add_ville_names (self):
        villes_names = []
        for ville in self.add_ville():
            villes_names.append(ville.city_name)
        return villes_names

    def add_capital(self):
        for ville in self.add_ville():
            if ville.isAdmin:
                return ville.city_name

    def add_population(self):
        population = 0
        for ville in self.add_ville():
            population+=ville.city_population

        return population

class List_Region:
    def __init__(self):
        self.regions = self.list_region()
        self.i = -1

    def list_region(self):
        regions = []
        regions_names=[]
        for ville in csv_reader():
            regions_names.append(ville.city_region)
        for r in set(regions_names):
            regions.append(Region(r))
        return regions
    def __iter__(self):
        return self
    def __next__(self):
        self.i+=1
        if self.i > len(self.regions)-1:
            raise StopIteration
        return self.regions[self.i]


class EncodeRegion(json.JSONEncoder):
    def default(self,r):
        if isinstance(r,Region):
            return r.__dict__
        else:
            return super().default(r)

regions = [region for region in List_Region()]
jstr=json.dumps(regions,cls=EncodeRegion,indent=4)

with open("regions.json","wt") as region:
    region.write(jstr)



