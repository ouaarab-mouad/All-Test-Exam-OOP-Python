class Mul:
    def __init__(self,N):
        self.__N = N
        self.__i = 0

    def __iter__(self):
        return self

    def __next__(self):
        self.__i+=1
        if self.__i*self.__N > self.__N ** 2:
            raise StopIteration
        return self.__i * self.__N

for m in Mul(8):
    print(m)
