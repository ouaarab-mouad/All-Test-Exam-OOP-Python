orders = [
        ["34587", "Learning Python, Mark Lutz", 4, 40.95],
        ["98762", "Programming Python, Mark Lutz", 5, 56.80],
        ["77226", "Head First Python, Paul Barry", 3,32.95],
        ["88112", "Einführung in Python3, Bernd Klein", 3, 24.99]
]

temp = list(map(lambda item:(item[0],item[2]*item[3]),orders))
print(temp)
rest = list(map(lambda item:(item[0],item[1]+10 if item[1]<100 else item[1]),temp))
print(rest)
