class conway:
    def __init__(self,n):
        self.__n = n
        self.__i = 0
        self.__xi = ""
        self.__xi_1 = "1"

    def __iter__(self):
        return self

    def __next__(self):

        if self.__i > self.__n - 1:
            raise StopIteration
        if self.__i == 0:
            ret = "1"
        else:
            while self.__xi_1:
                self.__xi+=str(len(self.__xi_1)- len(self.__xi_1.lstrip(self.__xi_1[0])))+self.__xi_1[0]
                self.__xi_1 = self.__xi_1.lstrip(self.__xi_1[0])
            ret = self.__xi
            self.__xi_1 ,self.__xi = self.__xi,""
        self.__i+=1
        return ret

for c in conway(10):
    print(c)
