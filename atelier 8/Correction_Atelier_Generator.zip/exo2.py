def conway(n):
    xi_1 = "1"
    xi = ""
    for i in range(n):
        if i == 0:
            yield "1"
        else:
            while xi_1:
                xi+= str(len(xi_1) - len(xi_1.lstrip(xi_1[0])))+xi_1[0]
                xi_1 = xi_1.lstrip(xi_1[0])
            yield xi
            xi_1,xi = xi,""

for c in conway(10):
    print(c)
