def frange(start,stop=None,step=None):
    if stop == None:
        stop = start
        start = 0
    if step == None:
        step = 1
    fra = start
    while True:
        yield fra
        fra +=step
        if fra >= stop:
            break

for i in frange(5.6):
    print(i, end=", ")
print()
for i in frange(0.3, 5.6):
    print(i, end=", ")
print()
for i in frange(0.3, 5.6, 0.8):
    print(i, end=", ")
print()
